@echo off
cd /d C:\TimeNet
start "" pythonw C:\TimeNet\admin.py
