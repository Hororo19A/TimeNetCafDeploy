╔══════════════════════════════════════════════════════════════════════════════╗
║              TimeNet Cafe — Internet Cafe Management System                  ║
║                          README & Setup Guide                                ║
╚══════════════════════════════════════════════════════════════════════════════╝

OVERVIEW
════════
TimeNet Cafe consists of two separate applications:

  1. admin.py      — Staff / Manager portal (non-kiosk, can be minimised)
  2. customer.py   — Customer kiosk (FULL LOCKDOWN — no exit, no taskbar)

The kiosk application runs each customer PC in a true locked-down state:
  • No taskbar (hidden while locked)
  • All hotkeys blocked:  Win key, Alt+Tab, Alt+F4, Ctrl+Esc, Ctrl+Alt+Del,
    Ctrl+Shift+Esc (Task Manager), F12, Win+D, Win+R, Win+E, Win+L, etc.
  • SAS (Ctrl+Alt+Delete) screen: Task Manager, Lock Workstation, and
    Change Password entries are disabled via registry while kiosk is running.
  • Watchdog thread re-grabs focus every 1.5 seconds if anything else steals it.
  • Window is borderless fullscreen, cannot be resized, moved, or minimised.
  • The ONLY way to close the kiosk app is via the Admin Exit PIN.

════════════════════════════════════════════════════════════════════════════════
QUICK START — FRESH INSTALL
════════════════════════════════════════════════════════════════════════════════

Prerequisites
─────────────
  • Windows 10 / 11  (64-bit recommended)
  • Python 3.9 or newer  →  https://www.python.org/downloads/
    ✔ Check "Add Python to PATH" during install
  • XAMPP  →  https://www.apachefriends.org/
    (or any MySQL 5.7+ / MariaDB 10.3+ server)

Step 1 — Install XAMPP and start MySQL
  a. Download and install XAMPP.
  b. Open XAMPP Control Panel → click  Start  next to MySQL.
  c. MySQL should show green and port 3306.

Step 2 — Run the Installer
  a. Right-click  install_timenet.py  → "Run as Administrator"
     (Administrator rights are needed to hide the taskbar and block hotkeys.)
  b. Follow the on-screen prompts:
       • DB Host:        localhost  (default)
       • DB Port:        3306       (default)
       • DB User:        root       (default for XAMPP)
       • DB Password:    (blank for XAMPP default — just press Enter)
       • Computer ID:    pc-01      (change for each PC: pc-01, pc-02, …)
       • Hourly Rate:    20         (PHP per hour)
       • Admin PIN:      1234       (change this!)
  c. The installer will:
       ✔ Install Python packages (mysql-connector-python, Pillow, requests, pystray)
       ✔ Import the database  (timenet_newfinal.sql)
       ✔ Write  C:\TimeNet\config.ini
       ✔ Copy app files to  C:\TimeNet\
       ✔ Create Desktop shortcuts

Step 3 — Launch
  Admin PC:     Double-click  "TimeNet Admin"  on the Desktop
  Customer PC:  Double-click  "TimeNet Kiosk"  on the Desktop

════════════════════════════════════════════════════════════════════════════════
MULTI-PC SETUP (NETWORKED CAFE)
════════════════════════════════════════════════════════════════════════════════

Server / Admin PC
─────────────────
  • Run XAMPP MySQL on this machine (it is the database server).
  • Run admin.py on this machine.
  • Note this machine's local IP address (e.g. 192.168.1.10).

Customer PCs
────────────
  • Copy the TimeNet folder to each customer PC (or map a network share).
  • Run install_timenet.py on EACH customer PC.
  • When prompted for DB Host, enter the SERVER's IP (e.g. 192.168.1.10).
  • Enter a UNIQUE Computer ID for each PC: pc-01, pc-02, pc-03, …
  • The customer app uses a limited DB user  (timenet_user / your password).

Create the limited MySQL user on the server:
  Open phpMyAdmin → SQL tab → paste:

    CREATE USER IF NOT EXISTS 'timenet_user'@'%'
      IDENTIFIED BY 'YourStrongPassword123';
    GRANT SELECT, INSERT, UPDATE ON timenet.* TO 'timenet_user'@'%';
    FLUSH PRIVILEGES;

  Then set  Customer DB username = timenet_user
            Customer DB password = YourStrongPassword123
  in the installer for each customer PC.

════════════════════════════════════════════════════════════════════════════════
KIOSK LOCKDOWN DETAILS
════════════════════════════════════════════════════════════════════════════════

What is blocked while in kiosk mode:
  ✗  Win key (all Win+* combos)
  ✗  Alt+Tab      (task switcher)
  ✗  Alt+F4       (close window)
  ✗  Alt+Esc      (switch window)
  ✗  Ctrl+Esc     (Start menu)
  ✗  Ctrl+Alt+Del (SAS screen — via registry DisableTaskMgr)
  ✗  Ctrl+Shift+Esc (Task Manager — via registry)
  ✗  Win+D  Win+E  Win+L  Win+R  Win+X  (desktop shortcuts)
  ✗  F12           (browser DevTools shortcut)
  ✗  Context Menu key
  ✗  Taskbar       (hidden continuously via ShowWindow API)
  ✗  Close / resize / minimise buttons (window borderless)
  ✗  Watchdog re-raises window every 1.5 s if anything else steals focus

What is NOT blocked:
  ✓  Normal typing in the kiosk UI (username, password, etc.)
  ✓  Ctrl+C / Ctrl+V inside text fields
  ✓  Ctrl+Shift+A  →  triggers Admin Exit PIN dialog (staff only)

Admin Exit (the ONLY way to close the kiosk):
  Press  Ctrl + Shift + A  anywhere in the kiosk.
  A PIN dialog appears. Enter the Admin PIN (default: 1234).
  On success the kiosk closes, taskbar is restored, and registry entries
  are cleaned up automatically.

Session Unlock Mode:
  When a customer's session is active the kiosk enters "session mode":
  • The main kiosk window minimises off-screen (hidden).
  • A small floating timer widget appears (bottom-right corner).
  • The taskbar reappears so the customer can use the PC normally.
  • Hotkey blocking is SUSPENDED while the session is active.
  When time runs out or the session ends, the kiosk re-locks automatically.

════════════════════════════════════════════════════════════════════════════════
CHANGING THE ADMIN PIN
════════════════════════════════════════════════════════════════════════════════

Edit  C:\TimeNet\config.ini  and change:

  [kiosk]
  admin_pin = 1234    ← change this

Save and restart the app.  No code editing needed.

════════════════════════════════════════════════════════════════════════════════
FILE STRUCTURE
════════════════════════════════════════════════════════════════════════════════

C:\TimeNet\
  admin.py              — Admin portal application
  customer.py           — Customer kiosk application
  config.ini            — Generated by installer (DB, PIN, computer ID)
  timenet_newfinal.sql  — Database schema (for re-import if needed)
  launch_admin.bat      — Admin launcher script
  launch_kiosk.bat      — Kiosk launcher script
  timenet.png           — App icon (optional)
  gcash.png             — GCash logo (optional)
  maya.png              — Maya logo (optional)

Desktop shortcuts:
  TimeNet Admin.bat     — Launches admin portal
  TimeNet Kiosk.bat     — Launches customer kiosk

════════════════════════════════════════════════════════════════════════════════
TROUBLESHOOTING
════════════════════════════════════════════════════════════════════════════════

"Can't connect to database"
  → Make sure XAMPP MySQL is running (green in Control Panel).
  → Check DB_HOST in config.ini matches the server IP.
  → If using a network DB, check Windows Firewall allows port 3306.

Kiosk doesn't start on boot
  → Run the installer as Administrator and say YES to the autostart question.
  → Or: add  C:\TimeNet\launch_kiosk.bat  to the Windows Startup folder
    (%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup).

Task Manager still accessible
  → Run the installer as Administrator (needed for registry writes).
  → The DisableTaskMgr registry key requires admin rights to write.

Taskbar still visible
  → This requires the app to run as Administrator, or the Windows account
    must have sufficient privileges to call ShowWindow on the Shell_TrayWnd.

Ctrl+Alt+Del screen still shows
  → The DisableTaskMgr registry key (HKCU) disables the Task Manager entry
    in the CAD screen but cannot fully remove the CAD screen itself without
    Group Policy (requires Windows Pro/Enterprise + domain or local GPO).
  → For maximum lockdown: set a Group Policy via gpedit.msc →
    User Configuration → Administrative Templates → System →
    "Disable the lock computer feature" and "Remove Task Manager".

Screen goes to sleep / screensaver activates during session
  → Open Power Settings → set "Turn off display" and "Sleep" to Never.
  → Or set via CMD (run as admin):
      powercfg /change standby-timeout-ac 0
      powercfg /change monitor-timeout-ac 0

════════════════════════════════════════════════════════════════════════════════
DEFAULT CREDENTIALS
════════════════════════════════════════════════════════════════════════════════

  Admin login:  username = admin   password = admin1234
  Test user:    username = testuser password = testpass
  Admin PIN:    1234  (change this in config.ini !)

════════════════════════════════════════════════════════════════════════════════
