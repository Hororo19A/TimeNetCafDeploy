@echo off
cd /d C:\TimeNet
start "" pythonw C:\TimeNet\customer.py
