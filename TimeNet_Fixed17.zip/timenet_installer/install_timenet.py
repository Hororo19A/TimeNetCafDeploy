"""
╔══════════════════════════════════════════════════════════════════════════════╗
║              TimeNet Cafe — Full System Installer                            ║
║                                                                              ║
║  Run this script ONCE on the server/admin machine OR on each kiosk PC.      ║
║  What it does:                                                               ║
║    1.  Checks Python version (3.9+)                                          ║
║    2.  Installs all required pip packages                                    ║
║    3.  Detects XAMPP / MySQL and imports the database                        ║
║    4.  Writes a config.ini that both apps read at startup                    ║
║    5.  Creates desktop shortcuts (.bat launchers) for Admin and Customer     ║
║    6.  Creates Windows startup entries (optional)                            ║
║    7.  Verifies everything and prints a summary                              ║
║                                                                              ║
║  Usage:  python install_timenet.py                                           ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import sys
import os
import subprocess
import platform
import shutil
import winreg
import ctypes
import configparser
import socket
import textwrap
from pathlib import Path
from datetime import datetime

# ──────────────────────────────────────────────────────────────────────────────
#  COLOUR CODES  (Windows ANSI via ConEmu / Windows Terminal / modern cmd)
# ──────────────────────────────────────────────────────────────────────────────
BOLD   = "\033[1m"
CYAN   = "\033[96m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
DIM    = "\033[2m"
RESET  = "\033[0m"

def _enable_ansi():
    """Enable ANSI escape codes on Windows 10+."""
    if platform.system() == "Windows":
        try:
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        except Exception:
            pass

_enable_ansi()

def hdr(text):
    w = 74
    print(f"\n{CYAN}{'═'*w}{RESET}")
    print(f"{CYAN}  {BOLD}{text}{RESET}")
    print(f"{CYAN}{'═'*w}{RESET}\n")

def ok(msg):
    print(f"  {GREEN}✓{RESET}  {msg}")

def warn(msg):
    print(f"  {YELLOW}⚠{RESET}  {msg}")

def err(msg):
    print(f"  {RED}✗{RESET}  {msg}")

def info(msg):
    print(f"  {DIM}→{RESET}  {msg}")

def ask(prompt, default=""):
    val = input(f"  {YELLOW}?{RESET}  {prompt} [{default}]: ").strip()
    return val if val else default

def ask_yn(prompt, default="y"):
    val = input(f"  {YELLOW}?{RESET}  {prompt} [{'Y/n' if default=='y' else 'y/N'}]: ").strip().lower()
    if not val:
        return default == "y"
    return val in ("y", "yes")

# ──────────────────────────────────────────────────────────────────────────────
#  REQUIRED PACKAGES
# ──────────────────────────────────────────────────────────────────────────────

REQUIRED_PACKAGES = [
    ("mysql-connector-python", "mysql.connector"),
    ("Pillow",                  "PIL"),
    ("requests",                "requests"),
    ("pystray",                 "pystray"),
]

# ──────────────────────────────────────────────────────────────────────────────
#  COMMON MYSQL / XAMPP PATHS
# ──────────────────────────────────────────────────────────────────────────────

MYSQL_PATHS = [
    r"C:\xampp\mysql\bin\mysql.exe",
    r"C:\xampp\bin\mysql.exe",
    r"C:\wamp64\bin\mysql\mysql8.0.31\bin\mysql.exe",
    r"C:\wamp\bin\mysql\mysql5.7.31\bin\mysql.exe",
    r"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe",
    r"C:\Program Files\MySQL\MySQL Server 5.7\bin\mysql.exe",
    r"C:\Program Files (x86)\MySQL\MySQL Server 5.7\bin\mysql.exe",
]

INSTALL_DIR = Path(r"C:\TimeNet")
SCRIPT_DIR  = Path(__file__).parent.resolve()

# ──────────────────────────────────────────────────────────────────────────────
#  STEP 1 — CHECK PYTHON
# ──────────────────────────────────────────────────────────────────────────────

def check_python():
    hdr("Step 1 — Python Version Check")
    major, minor = sys.version_info[:2]
    info(f"Python {major}.{minor}.{sys.version_info.micro} detected at {sys.executable}")
    if (major, minor) < (3, 9):
        err("Python 3.9 or higher is required.")
        err("Download from https://www.python.org/downloads/")
        sys.exit(1)
    ok(f"Python {major}.{minor} — OK")
    if platform.system() != "Windows":
        warn("This installer is optimised for Windows.")
        warn("Some kiosk lockdown features (taskbar hide, hotkey block) are Windows-only.")


# ──────────────────────────────────────────────────────────────────────────────
#  STEP 2 — INSTALL PACKAGES
# ──────────────────────────────────────────────────────────────────────────────

def install_packages():
    hdr("Step 2 — Python Package Installation")
    failed = []
    for pkg_name, import_name in REQUIRED_PACKAGES:
        try:
            __import__(import_name)
            ok(f"{pkg_name} — already installed")
        except ImportError:
            info(f"Installing {pkg_name}…")
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg_name, "--quiet"],
                capture_output=True, text=True)
            if result.returncode == 0:
                ok(f"{pkg_name} — installed")
            else:
                err(f"Failed to install {pkg_name}")
                warn(result.stderr.strip()[:200])
                failed.append(pkg_name)
    if failed:
        err(f"Could not install: {', '.join(failed)}")
        warn("Run:  pip install " + " ".join(failed))
    else:
        ok("All packages ready")


# ──────────────────────────────────────────────────────────────────────────────
#  STEP 3 — DATABASE SETUP
# ──────────────────────────────────────────────────────────────────────────────

def find_mysql():
    m = shutil.which("mysql")
    if m:
        return m
    for p in MYSQL_PATHS:
        if os.path.exists(p):
            return p
    return None


def test_db_connect(host, port, user, password):
    try:
        import mysql.connector
        conn = mysql.connector.connect(
            host=host, port=int(port), user=user, password=password,
            connect_timeout=6)
        conn.close()
        return True, None
    except Exception as e:
        return False, str(e)


def setup_database(cfg):
    hdr("Step 3 — Database Setup")
    mysql_bin = find_mysql()
    if mysql_bin:
        ok(f"MySQL client found: {mysql_bin}")
    else:
        warn("MySQL client (mysql.exe) not found in PATH or common XAMPP locations.")
        warn("Make sure XAMPP / MySQL is running BEFORE continuing.")
        mysql_bin = ask("Enter full path to mysql.exe (or leave blank to skip import)", "")

    host     = cfg.get("database", "host",     fallback="localhost")
    port     = cfg.get("database", "port",     fallback="3306")
    user     = cfg.get("database", "user",     fallback="root")
    password = cfg.get("database", "password", fallback="")

    print()
    info("Database connection settings:")
    host     = ask("DB Host",     host)
    port     = ask("DB Port",     port)
    user     = ask("DB User",     user)
    password = ask("DB Password", password)

    ok_conn, err_msg = test_db_connect(host, port, user, password)
    if ok_conn:
        ok(f"Connected to MySQL at {host}:{port}")
    else:
        err(f"Cannot connect: {err_msg}")
        warn("Make sure XAMPP / MySQL service is running.")
        if not ask_yn("Continue anyway?", "n"):
            sys.exit(1)

    # Try to import the SQL file
    sql_file = SCRIPT_DIR / "timenet_newfinal.sql"
    if not sql_file.exists():
        warn(f"SQL file not found at: {sql_file}")
        sql_file_str = ask("Enter full path to timenet_newfinal.sql", "")
        sql_file = Path(sql_file_str) if sql_file_str else None

    if sql_file and sql_file.exists() and mysql_bin:
        if ask_yn(f"Import/update database from {sql_file.name}?", "y"):
            pw_flag = f"-p{password}" if password else ""
            cmd = [mysql_bin, f"-h{host}", f"-P{port}", f"-u{user}"]
            if password:
                cmd.append(f"-p{password}")
            try:
                import tempfile, codecs
                # Write SQL to a UTF-8 temp file to avoid CP1252 pipe encoding issues
                with tempfile.NamedTemporaryFile(mode="w", suffix=".sql",
                                                  encoding="utf-8", delete=False) as tf:
                    tmp_sql = tf.name
                    with open(sql_file, "r", encoding="utf-8") as sf:
                        tf.write(sf.read())
                # Use file redirection instead of stdin pipe
                cmd_with_file = cmd + [f"--execute=source {tmp_sql}"]
                result = subprocess.run(
                    cmd_with_file,
                    capture_output=True, timeout=30)
                if result.returncode != 0:
                    # Fallback: use < file redirection via shell
                    shell_cmd = " ".join(f'"{c}"' if " " in c else c for c in cmd)
                    shell_cmd += f' < "{tmp_sql}"'
                    result2 = subprocess.run(shell_cmd, shell=True,
                                             capture_output=True, timeout=30)
                    if result2.returncode == 0:
                        ok("Database imported successfully")
                    else:
                        warn(f"MySQL returned code {result2.returncode}")
                        stderr = result2.stderr.decode("utf-8", errors="replace").strip()
                        if stderr:
                            warn(stderr[:300])
                else:
                    ok("Database imported successfully")
                try:
                    os.unlink(tmp_sql)
                except Exception:
                    pass
            except subprocess.TimeoutExpired:
                err("MySQL import timed out")
            except Exception as ex:
                err(f"Import failed: {ex}")
    else:
        warn("Skipping automatic database import.")
        warn("You can import manually:  mysql -u root < timenet_newfinal.sql")

    return host, port, user, password


# ──────────────────────────────────────────────────────────────────────────────
#  STEP 4 — WRITE CONFIG
# ──────────────────────────────────────────────────────────────────────────────

def write_config(host, port, user, password,
                 computer_id, hourly_rate, admin_pin,
                 customer_db_user, customer_db_password):
    hdr("Step 4 — Writing Configuration File")

    cfg = configparser.ConfigParser()
    cfg["database"] = {
        "host":     host,
        "port":     port,
        "user":     user,
        "password": password,
        "name":     "timenet",
    }
    cfg["database_customer"] = {
        "host":     host,
        "port":     port,
        "user":     customer_db_user,
        "password": customer_db_password,
        "name":     "timenet",
    }
    cfg["kiosk"] = {
        "computer_id": computer_id,
        "hourly_rate": str(hourly_rate),
        "admin_pin":   admin_pin,
    }
    cfg["paths"] = {
        "install_dir": str(INSTALL_DIR),
        "scripts_dir": str(INSTALL_DIR),
    }
    cfg["meta"] = {
        "installed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "installed_by": os.environ.get("USERNAME", "unknown"),
        "hostname":     socket.gethostname(),
    }

    config_path = INSTALL_DIR / "config.ini"
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w") as f:
        cfg.write(f)

    ok(f"Config written to: {config_path}")
    return config_path


# ──────────────────────────────────────────────────────────────────────────────
#  STEP 5 — COPY APPLICATION FILES
# ──────────────────────────────────────────────────────────────────────────────

def copy_app_files():
    hdr("Step 5 — Copying Application Files")
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)

    files_to_copy = [
        ("admin.py",    "admin.py"),
        ("customer.py", "customer.py"),
        ("timenet_newfinal.sql", "timenet_newfinal.sql"),
    ]

    for src_name, dst_name in files_to_copy:
        src = SCRIPT_DIR / src_name
        dst = INSTALL_DIR / dst_name
        if src.exists():
            shutil.copy2(src, dst)
            ok(f"Copied {src_name} → {dst}")
        else:
            warn(f"Source not found: {src}  (skipping)")

    # Copy optional icon files if present
    for icon in ("timenet.png", "gcash.png", "maya.png", "timenet.ico"):
        src_icon = SCRIPT_DIR / icon
        if src_icon.exists():
            shutil.copy2(src_icon, INSTALL_DIR / icon)
            ok(f"Copied icon: {icon}")


# ──────────────────────────────────────────────────────────────────────────────
#  STEP 6 — CREATE LAUNCHER SCRIPTS
# ──────────────────────────────────────────────────────────────────────────────

ADMIN_BAT = """\
@echo off
title TimeNet Admin
cd /d C:\\TimeNet
start "" pythonw C:\\TimeNet\\admin.py
"""

CUSTOMER_BAT = """\
@echo off
title TimeNet Kiosk
cd /d C:\\TimeNet
start "" pythonw C:\\TimeNet\\customer.py
"""

ADMIN_VBS = """\
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """" & WScript.ScriptFullName & """", 0, False
"""

# Silent customer launcher (no console window)
CUSTOMER_SILENT_BAT = """\
@echo off
title TimeNet Kiosk
cd /d C:\\TimeNet
start /min "" pythonw customer.py
"""


def create_launchers():
    hdr("Step 6 — Creating Launcher Scripts")
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)

    # Admin launcher
    admin_bat = INSTALL_DIR / "launch_admin.bat"
    admin_bat.write_text(ADMIN_BAT)
    ok(f"Admin launcher: {admin_bat}")

    # Customer launcher (silent, no console)
    cust_bat = INSTALL_DIR / "launch_kiosk.bat"
    cust_bat.write_text(CUSTOMER_SILENT_BAT)
    ok(f"Customer launcher: {cust_bat}")

    # Desktop shortcuts
    desktop = Path(os.path.expanduser("~")) / "Desktop"
    _create_shortcut(
        name="TimeNet Admin",
        target=str(admin_bat),
        working_dir=str(INSTALL_DIR),
        icon_desc="Admin Portal",
        desktop=desktop,
    )
    _create_shortcut(
        name="TimeNet Kiosk",
        target=str(cust_bat),
        working_dir=str(INSTALL_DIR),
        icon_desc="Customer Kiosk",
        desktop=desktop,
    )

    return admin_bat, cust_bat


def _create_shortcut(name, target, working_dir, icon_desc, desktop):
    """Create a .lnk Windows shortcut with the TimeNet icon."""
    import subprocess
    lnk = desktop / f"{name}.lnk"
    icon_path = str(INSTALL_DIR / "timenet.ico")
    # Use PowerShell WScript.Shell to create a proper .lnk with icon
    ps_script = (
        f'$ws = New-Object -ComObject WScript.Shell; '
        f'$s = $ws.CreateShortcut("{lnk}"); '
        f'$s.TargetPath = "pythonw.exe"; '
        f'$s.Arguments = "C:\\TimeNet\\{Path(target).name.replace(".bat", ".py")}"; '
        f'$s.WorkingDirectory = "{working_dir}"; '
        f'$s.IconLocation = "{icon_path}"; '
        f'$s.Description = "{icon_desc}"; '
        f'$s.Save()'
    )
    try:
        subprocess.run(
            ["powershell", "-WindowStyle", "Hidden", "-Command", ps_script],
            check=True, capture_output=True
        )
        ok(f"Desktop shortcut: {lnk.name}")
    except Exception as ex:
        warn(f"Could not create .lnk shortcut for {name}: {ex}")
        # Fallback to bat
        bat = desktop / f"{name}.bat"
        bat.write_text(f'@echo off\ncall "{target}"\n')
        ok(f"Desktop shortcut (bat fallback): {bat.name}")


# ──────────────────────────────────────────────────────────────────────────────
#  STEP 7 — WINDOWS STARTUP (KIOSK AUTO-START)
# ──────────────────────────────────────────────────────────────────────────────

def setup_autostart(cust_bat):
    hdr("Step 7 — Kiosk Auto-Start on Windows Login")
    if platform.system() != "Windows":
        warn("Auto-start setup is Windows-only — skipping.")
        return

    if not ask_yn("Add TimeNet Kiosk to Windows startup (auto-launch on login)?", "y"):
        info("Skipping auto-start setup.")
        return

    # Write to HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE)
        # Use wscript + VBS launcher so no console window flashes on startup
        vbs_path = INSTALL_DIR / "launch_kiosk_silent.vbs"
        run_cmd = f'wscript.exe "{vbs_path}"'
        winreg.SetValueEx(key, "TimeNetKiosk", 0, winreg.REG_SZ, run_cmd)
        winreg.CloseKey(key)
        ok("Auto-start registry entry added (HKCU Run)")
    except Exception as ex:
        warn(f"Could not add to registry: {ex}")
        warn("Manually add to Task Scheduler or Startup folder if needed.")


# ──────────────────────────────────────────────────────────────────────────────
#  STEP 8 — VERIFY INSTALLATION
# ──────────────────────────────────────────────────────────────────────────────

def verify():
    hdr("Step 8 — Verifying Installation")
    checks = [
        (INSTALL_DIR / "admin.py",              "admin.py"),
        (INSTALL_DIR / "customer.py",           "customer.py"),
        (INSTALL_DIR / "config.ini",            "config.ini"),
        (INSTALL_DIR / "launch_admin.bat",      "launch_admin.bat"),
        (INSTALL_DIR / "launch_kiosk.bat",      "launch_kiosk.bat"),
    ]
    all_ok = True
    for path, label in checks:
        if path.exists():
            ok(f"{label} — found")
        else:
            err(f"{label} — MISSING")
            all_ok = False
    return all_ok


# ──────────────────────────────────────────────────────────────────────────────
#  SUMMARY
# ──────────────────────────────────────────────────────────────────────────────

def print_summary(admin_pin, computer_id, config_path):
    hdr("Installation Complete")
    print(textwrap.dedent(f"""
  {GREEN}{BOLD}TimeNet Cafe has been installed successfully!{RESET}

  {BOLD}Installation directory:{RESET}  {INSTALL_DIR}
  {BOLD}Config file:{RESET}             {config_path}

  {BOLD}To launch the Admin Panel:{RESET}
      Double-click  "TimeNet Admin"  on the Desktop
      — or —
      Run:  C:\\TimeNet\\launch_admin.bat

  {BOLD}To launch the Customer Kiosk:{RESET}
      Double-click  "TimeNet Kiosk"  on the Desktop
      — or —
      Run:  C:\\TimeNet\\launch_kiosk.bat

  {YELLOW}{BOLD}IMPORTANT — Admin Exit PIN:{RESET}
      The kiosk is in full lockdown mode.
      To exit:  press  Ctrl + Shift + A  then enter PIN:  {BOLD}{admin_pin}{RESET}

  {YELLOW}{BOLD}This PC's Kiosk ID:{RESET}  {computer_id}
      Make sure this matches the 'id' column in the computers table.

  {DIM}If you see DB errors, make sure XAMPP / MySQL is running first.{RESET}
    """))


# ──────────────────────────────────────────────────────────────────────────────
#  MAIN
# ──────────────────────────────────────────────────────────────────────────────

def main():
    print(f"\n{CYAN}{BOLD}")
    print("  ╔══════════════════════════════════════════════════╗")
    print("  ║     TimeNet Cafe — System Installer  v1.0        ║")
    print("  ╚══════════════════════════════════════════════════╝")
    print(f"{RESET}")
    print(f"  Installing to:  {INSTALL_DIR}")
    print(f"  Host:           {socket.gethostname()}")
    print(f"  Date:           {datetime.now().strftime('%B %d, %Y  %I:%M %p')}\n")

    if platform.system() == "Windows":
        is_admin_proc = ctypes.windll.shell32.IsUserAnAdmin()
        if not is_admin_proc:
            warn("Not running as Administrator.")
            warn("Some operations (registry, startup) may fail.")
            warn("Right-click install_timenet.py → 'Run as Administrator' for best results.\n")

    # Load any existing config
    cfg = configparser.ConfigParser()
    existing_config = INSTALL_DIR / "config.ini"
    if existing_config.exists():
        cfg.read(existing_config)
        info(f"Found existing config at {existing_config}")

    # ── Kiosk identity ────────────────────────────────────────────────────────
    hdr("Kiosk Identity")
    print("  Each PC in your cafe needs a unique Computer ID that matches")
    print("  the 'id' column in the  computers  table (e.g. pc-01, pc-02).\n")
    computer_id  = ask("This PC's Computer ID", cfg.get("kiosk", "computer_id", fallback="pc-01"))
    hourly_rate  = ask("Hourly rate (PHP)",      cfg.get("kiosk", "hourly_rate",  fallback="20"))
    admin_pin    = ask("Admin exit PIN",          cfg.get("kiosk", "admin_pin",    fallback="1234"))

    print()
    hdr("Customer DB Credentials")
    print("  The Customer app connects with a limited MySQL user for security.")
    print("  Create this user in phpMyAdmin:  CREATE USER 'timenet_user'@'localhost'")
    print("  IDENTIFIED BY 'yourpassword'; GRANT SELECT,INSERT,UPDATE ON timenet.* TO ...\n")
    customer_db_user = ask("Customer DB username", cfg.get("database_customer", "user", fallback="timenet_user"))
    customer_db_pass = ask("Customer DB password", cfg.get("database_customer", "password", fallback=""))

    # Run steps
    check_python()
    install_packages()
    host, port, user, password = setup_database(cfg)
    config_path = write_config(
        host, port, user, password,
        computer_id, hourly_rate, admin_pin,
        customer_db_user, customer_db_pass)
    copy_app_files()
    _, cust_bat = create_launchers()
    setup_autostart(cust_bat)
    verify()
    print_summary(admin_pin, computer_id, config_path)

    input(f"\n  {DIM}Press Enter to close the installer…{RESET}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n  {YELLOW}Installation cancelled.{RESET}\n")
        sys.exit(0)
