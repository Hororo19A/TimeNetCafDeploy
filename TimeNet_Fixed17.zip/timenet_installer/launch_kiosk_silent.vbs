' TimeNet Kiosk — Silent Launcher (no console window)
' Double-click this file to launch the kiosk without a black CMD window.
' Place in C:\TimeNet\ alongside customer.py

Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "C:\TimeNet"
WshShell.Run "pythonw.exe C:\TimeNet\customer.py", 0, False
