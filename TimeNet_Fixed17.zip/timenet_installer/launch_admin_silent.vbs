' TimeNet Admin — Silent Launcher (no console window)
' Double-click this to launch the admin portal without a black CMD window.
' Place in C:\TimeNet\ alongside admin.py

Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "C:\TimeNet"
WshShell.Run "pythonw.exe C:\TimeNet\admin.py", 0, False
