@echo off
:: TimeNet — Create Desktop Shortcuts with Custom Icon
:: Run this once to fix the icon on your desktop shortcuts.

set TIMENET=C:\TimeNet
set DESKTOP=%USERPROFILE%\Desktop

powershell -WindowStyle Hidden -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $s = $ws.CreateShortcut('%DESKTOP%\TimeNet Kiosk.lnk'); ^
   $s.TargetPath = 'pythonw.exe'; ^
   $s.Arguments = 'C:\TimeNet\customer.py'; ^
   $s.WorkingDirectory = '%TIMENET%'; ^
   $s.IconLocation = '%TIMENET%\timenet.ico'; ^
   $s.Description = 'TimeNet Customer Kiosk'; ^
   $s.Save()"

powershell -WindowStyle Hidden -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $s = $ws.CreateShortcut('%DESKTOP%\TimeNet Admin.lnk'); ^
   $s.TargetPath = 'pythonw.exe'; ^
   $s.Arguments = 'C:\TimeNet\admin.py'; ^
   $s.WorkingDirectory = '%TIMENET%'; ^
   $s.IconLocation = '%TIMENET%\timenet.ico'; ^
   $s.Description = 'TimeNet Admin Portal'; ^
   $s.Save()"

echo Done! Check your Desktop for TimeNet Kiosk and TimeNet Admin shortcuts.
pause
