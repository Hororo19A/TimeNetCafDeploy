"""
TimeNet Cafe — Installer
========================
Run this once on each PC to install the Customer Kiosk or Admin Portal.
Usage:
    python install.py          → interactive mode (asks which role)
    python install.py customer → install customer kiosk silently
    python install.py admin    → install admin portal silently
"""

import sys
import os
import re
import subprocess
import shutil
import platform
import winreg
import traceback
import getpass
from pathlib import Path

# ─────────────────────────────────────────────────────────────
#  CONFIG — edit these before distributing
# ─────────────────────────────────────────────────────────────

APP_NAME        = "TimeNet Cafe"
INSTALL_DIR     = Path(r"C:\TimeNet")
CUSTOMER_SCRIPT = "customerNEW.py"
ADMIN_SCRIPT    = "adminNEW.py"
ASSETS          = ["gcash.png", "maya.png", "cash.png", "timenet.png", "timenet_newfinal.sql"]

PYTHON_PACKAGES = [
    "mysql-connector-python",
    "requests",
    "Pillow",
    "pystray",
]

STARTUP_REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"

# ─────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────

def banner(msg):
    w = 60
    print("\n" + "═" * w)
    print(f"  {msg}")
    print("═" * w)

def step(msg):
    print(f"\n  ▶  {msg}")

def ok(msg="Done"):
    print(f"     ✓  {msg}")

def fail(msg):
    print(f"\n  ✗  ERROR: {msg}")
    sys.exit(1)

def ask(prompt, default="", secret=False):
    """Prompt the user for input, showing the default in brackets."""
    display_default = "****" if (secret and default) else default
    suffix = f" [{display_default}]" if display_default else ""
    full_prompt = f"     {prompt}{suffix}: "
    if secret:
        val = getpass.getpass(full_prompt)
    else:
        val = input(full_prompt).strip()
    return val if val else default

def ask_int(prompt, default):
    """Prompt for an integer value."""
    while True:
        raw = ask(prompt, str(default))
        try:
            return int(raw)
        except ValueError:
            print(f"     ⚠  Please enter a number.")

def section(title):
    print(f"\n  ── {title} {'─' * (48 - len(title))}")


# ─────────────────────────────────────────────────────────────
#  CONFIGURATION WIZARD
# ─────────────────────────────────────────────────────────────

def run_config_wizard():
    """
    Interactive wizard to collect DB, PayMongo, and app settings.
    Returns a dict with all config values.
    """
    print("""
╔══════════════════════════════════════════════════════════╗
║         TimeNet Cafe  —  Configuration Wizard           ║
╠══════════════════════════════════════════════════════════╣
║  Set up your database connection, PayMongo keys, and    ║
║  admin PIN before installation.                         ║
║                                                          ║
║  Press Enter to keep the default value shown in [ ].   ║
╚══════════════════════════════════════════════════════════╝
""")

    # ── Database ──────────────────────────────────────────────
    section("Database Connection")
    db_host     = ask("MySQL host",     "localhost")
    db_port     = ask_int("MySQL port", 3306)
    db_user     = ask("MySQL username", "root")
    db_password = ask("MySQL password", "", secret=True)
    db_name     = ask("Database name",  "timenet")

    # Quick connection test
    print()
    print("     Testing database connection…", end=" ", flush=True)
    try:
        import mysql.connector
        conn = mysql.connector.connect(
            host=db_host, port=db_port,
            user=db_user, password=db_password,
            database=db_name, connect_timeout=6,
        )
        conn.close()
        print("✓  Connected!")
    except Exception as e:
        short = str(e).split("\n")[0][:80]
        print(f"\n     ⚠  Could not connect: {short}")
        cont = input("     Continue anyway? [y/N]: ").strip().lower()
        if cont != "y":
            fail("Aborted by user after failed DB test.")

    # ── PayMongo ──────────────────────────────────────────────
    section("PayMongo API Keys")
    print("     (Leave blank to keep the existing test keys)")
    pm_secret = ask("Secret key  (sk_live_… or sk_test_…)", "sk_test_knuivMbT2mfYaub4f6oDNh5y", secret=False)
    pm_public = ask("Public key  (pk_live_… or pk_test_…)", "pk_test_78P7sdJ2p33LmgwFLnrsTHQB")

    # ── Admin PIN ─────────────────────────────────────────────
    section("Admin Exit PIN")
    print("     (This PIN unlocks the kiosk / admin portal)")
    while True:
        pin = ask("Exit PIN (4–8 digits)", "1234", secret=True)
        if re.fullmatch(r"\d{4,8}", pin):
            break
        print("     ⚠  PIN must be 4–8 digits only.")

    # ── Summary ───────────────────────────────────────────────
    print(f"""
  ┌──────────────────────────────────────────────────────┐
  │  Configuration Summary                              │
  ├──────────────────────────────────────────────────────┤
  │  DB host      : {db_host:<36}│
  │  DB port      : {str(db_port):<36}│
  │  DB user      : {db_user:<36}│
  │  DB password  : {"(set)" if db_password else "(empty)":<36}│
  │  DB name      : {db_name:<36}│
  ├──────────────────────────────────────────────────────┤
  │  PayMongo sk  : {(pm_secret[:6] + "…" + pm_secret[-4:]) if len(pm_secret) > 12 else pm_secret:<36}│
  │  PayMongo pk  : {(pm_public[:6] + "…" + pm_public[-4:]) if len(pm_public) > 12 else pm_public:<36}│
  ├──────────────────────────────────────────────────────┤
  │  Admin PIN    : {"*" * len(pin):<36}│
  └──────────────────────────────────────────────────────┘""")

    confirm = input("\n  Proceed with these settings? [Y/n]: ").strip().lower()
    if confirm == "n":
        print("  Restarting wizard…")
        return run_config_wizard()

    return {
        "db_host":     db_host,
        "db_port":     db_port,
        "db_user":     db_user,
        "db_password": db_password,
        "db_name":     db_name,
        "pm_secret":   pm_secret,
        "pm_public":   pm_public,
        "admin_pin":   pin,
    }


def patch_script(script_path, cfg):
    """
    Patch the installed .py file in-place with the collected config values.
    Uses precise regex replacements targeting each CONFIG constant.
    """
    text = Path(script_path).read_text(encoding="utf-8")

    replacements = [
        # DB
        (r'^(DB_HOST\s*=\s*)["\'].*?["\']',   f'\\g<1>"{cfg["db_host"]}"'),
        (r'^(DB_PORT\s*=\s*)\d+',              f'\\g<1>{cfg["db_port"]}'),
        (r'^(DB_USER\s*=\s*)["\'].*?["\']',   f'\\g<1>"{cfg["db_user"]}"'),
        (r'^(DB_PASSWORD\s*=\s*)["\'].*?["\']', f'\\g<1>"{cfg["db_password"]}"'),
        (r'^(DB_NAME\s*=\s*)["\'].*?["\']',   f'\\g<1>"{cfg["db_name"]}"'),
        # PayMongo
        (r'^(PAYMONGO_SECRET_KEY\s*=\s*)["\'].*?["\']', f'\\g<1>"{cfg["pm_secret"]}"'),
        (r'^(PAYMONGO_PUBLIC_KEY\s*=\s*)["\'].*?["\']', f'\\g<1>"{cfg["pm_public"]}"'),
        # Admin PIN
        (r'^(ADMIN_EXIT_PIN\s*=\s*)["\'].*?["\']', f'\\g<1>"{cfg["admin_pin"]}"'),
    ]

    for pattern, repl in replacements:
        text = re.sub(pattern, repl, text, flags=re.MULTILINE)

    Path(script_path).write_text(text, encoding="utf-8")


# ─────────────────────────────────────────────────────────────
#  ORIGINAL HELPERS (unchanged)
# ─────────────────────────────────────────────────────────────

def find_python():
    return sys.executable

def find_pythonw():
    py = Path(sys.executable)
    pw = py.parent / "pythonw.exe"
    if pw.exists():
        return str(pw)
    return str(py)

def run(cmd, check=True):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if check and result.returncode != 0:
        print(result.stderr[-800:])
        fail(f"Command failed: {' '.join(str(c) for c in cmd)}")
    return result

def write_ansi(path, text):
    Path(path).write_bytes(text.encode("cp1252"))

def create_shortcut_vbs(target_exe, target_args, shortcut_path,
                        icon_path=None, work_dir=None):
    work_dir  = work_dir or str(INSTALL_DIR)
    icon_line = f'oShortcut.IconLocation = "{icon_path}"' if icon_path else ""
    vbs = (
        'Set oWS = WScript.CreateObject("WScript.Shell")\r\n'
        f'Set oShortcut = oWS.CreateShortcut("{shortcut_path}")\r\n'
        f'oShortcut.TargetPath = "{target_exe}"\r\n'
        f'oShortcut.Arguments = "{target_args}"\r\n'
        f'oShortcut.WorkingDirectory = "{work_dir}"\r\n'
        + (f'{icon_line}\r\n' if icon_line else "")
        + 'oShortcut.WindowStyle = 1\r\n'
          'oShortcut.Save\r\n'
    )
    vbs_path = Path(os.environ.get("TEMP", "C:\\Temp")) / "_timenet_shortcut.vbs"
    write_ansi(vbs_path, vbs)
    run(["cscript", "//NoLogo", str(vbs_path)])
    vbs_path.unlink(missing_ok=True)

def add_to_startup(name, vbs_launcher_path):
    cmd_value = f'"C:\\Windows\\System32\\wscript.exe" "{vbs_launcher_path}"'
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_REG_KEY,
                             0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, cmd_value)
        winreg.CloseKey(key)
        ok(f"Added to Windows startup: {name}")
    except Exception as e:
        print(f"     ⚠  Could not add to startup: {e}")

def remove_from_startup(name):
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_REG_KEY,
                             0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(key, name)
        winreg.CloseKey(key)
    except FileNotFoundError:
        pass

def get_desktop():
    try:
        import winreg as _wr
        k = _wr.OpenKey(_wr.HKEY_CURRENT_USER,
                        r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders")
        desktop, _ = _wr.QueryValueEx(k, "Desktop")
        return Path(desktop)
    except Exception:
        return Path(os.path.expanduser("~")) / "Desktop"

def make_ico_from_png(png_path, ico_path):
    try:
        from PIL import Image
        img = Image.open(str(png_path)).convert("RGBA")
        sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
        imgs = [img.resize(s, Image.Resampling.LANCZOS) for s in sizes]
        imgs[0].save(str(ico_path), format="ICO", sizes=sizes,
                     append_images=imgs[1:])
        return str(ico_path)
    except Exception as e:
        print(f"     ⚠  Could not create .ico: {e}")
        return None

def hide_file(path):
    try:
        subprocess.run(["attrib", "+H", str(path)], capture_output=True)
    except Exception:
        pass

def copy_source_files(role):
    src_dir = Path(__file__).parent / "src"
    if role == "customer":
        scripts = [CUSTOMER_SCRIPT]
    elif role == "admin":
        scripts = [ADMIN_SCRIPT]
    else:
        scripts = [CUSTOMER_SCRIPT, ADMIN_SCRIPT]

    for script in scripts:
        src = src_dir / script
        if not src.exists():
            src = Path(__file__).parent / script
        if not src.exists():
            fail(f"Source file not found: {script}\nExpected at: {src}")
        shutil.copy2(str(src), str(INSTALL_DIR / script))
        ok(f"Copied {script}")

    for asset in ASSETS:
        src = src_dir / asset
        if not src.exists():
            src = Path(__file__).parent / asset
        if src.exists():
            shutil.copy2(str(src), str(INSTALL_DIR / asset))
            ok(f"Copied asset: {asset}")

def _write_vbs_launcher(vbs_path, script_path):
    pythonw = find_pythonw()
    vbs_text = (
        'CreateObject("WScript.Shell").Run _\r\n'
        f'  Chr(34) & "{pythonw}" & Chr(34)'
        f' & " " & Chr(34) & "{script_path}" & Chr(34), 0, False\r\n'
    )
    write_ansi(vbs_path, vbs_text)


# ─────────────────────────────────────────────────────────────
#  INSTALL CUSTOMER KIOSK
# ─────────────────────────────────────────────────────────────

def install_customer(cfg):
    banner("Installing  TimeNet Cafe  —  Customer Kiosk")

    step("Creating install directory")
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    ok(str(INSTALL_DIR))

    step("Installing Python dependencies")
    python = find_python()
    for pkg in PYTHON_PACKAGES:
        print(f"     • {pkg} …", end=" ", flush=True)
        r = run([python, "-m", "pip", "install", pkg, "--quiet",
                 "--disable-pip-version-check"], check=False)
        print("✓" if r.returncode == 0 else f"WARN: {r.stderr[:120]}")

    step("Copying application files")
    copy_source_files("customer")

    step("Applying configuration (DB, PayMongo, PIN)")
    patch_script(INSTALL_DIR / CUSTOMER_SCRIPT, cfg)
    ok("Configuration applied")

    step("Creating launcher")
    pythonw      = find_pythonw()
    script_path  = str(INSTALL_DIR / CUSTOMER_SCRIPT)
    vbs_launcher = INSTALL_DIR / "launch_customer.vbs"
    _write_vbs_launcher(vbs_launcher, script_path)
    ok(f"VBS launcher: {vbs_launcher}")

    bat_launcher = INSTALL_DIR / "launch_customer_debug.bat"
    write_ansi(bat_launcher,
        f'@echo off\r\n'
        f'cd /d "{INSTALL_DIR}"\r\n'
        f'"{pythonw}" "{script_path}"\r\n'
        f'pause\r\n'
    )
    hide_file(bat_launcher)

    step("Creating desktop shortcut")
    try:
        desktop      = get_desktop()
        shortcut     = str(desktop / "TimeNet Kiosk.lnk")
        wscript      = r"C:\Windows\System32\wscript.exe"
        vbs_arg      = str(vbs_launcher)
        png_path     = INSTALL_DIR / "timenet.png"
        ico_path     = INSTALL_DIR / "timenet.ico"
        icon_path    = make_ico_from_png(png_path, ico_path) if png_path.exists() else None
        create_shortcut_vbs(
            target_exe    = wscript,
            target_args   = vbs_arg,
            shortcut_path = shortcut,
            icon_path     = icon_path,
        )
        ok(f"Shortcut: {shortcut}")
    except Exception as e:
        print(f"     ⚠  Could not create shortcut: {e}")

    step("Registering auto-start on Windows login")
    add_to_startup("TimeNet Customer Kiosk", str(vbs_launcher))

    _write_uninstaller("customer")

    banner("Customer Kiosk Installed Successfully!")
    print(f"""
  Installation directory : {INSTALL_DIR}
  Desktop shortcut       : TimeNet Kiosk.lnk
  Auto-starts with Windows: YES  (via wscript, no console)

  ┌──────────────────────────────────────────────────────┐
  │  IMPORTANT — Kiosk Lock Notes                       │
  │                                                      │
  │  • The app runs fullscreen with no title bar.        │
  │  • Windows key, Alt+F4, Ctrl+Esc are all blocked.   │
  │  • To exit: press Ctrl+Shift+A and enter your PIN.  │
  │                                                      │
  │  • Closing any CMD / terminal will NOT kill the app.│
  └──────────────────────────────────────────────────────┘

  To uninstall: run  {INSTALL_DIR}\\uninstall.bat
""")


# ─────────────────────────────────────────────────────────────
#  INSTALL ADMIN PORTAL
# ─────────────────────────────────────────────────────────────

def install_admin(cfg):
    banner("Installing  TimeNet Cafe  —  Admin Portal")

    step("Creating install directory")
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    ok(str(INSTALL_DIR))

    step("Installing Python dependencies")
    python = find_python()
    for pkg in PYTHON_PACKAGES:
        print(f"     • {pkg} …", end=" ", flush=True)
        r = run([python, "-m", "pip", "install", pkg, "--quiet",
                 "--disable-pip-version-check"], check=False)
        print("✓" if r.returncode == 0 else f"WARN: {r.stderr[:120]}")

    step("Copying application files")
    copy_source_files("admin")

    step("Applying configuration (DB, PayMongo, PIN)")
    patch_script(INSTALL_DIR / ADMIN_SCRIPT, cfg)
    ok("Configuration applied")

    step("Creating launcher")
    pythonw      = find_pythonw()
    script_path  = str(INSTALL_DIR / ADMIN_SCRIPT)
    vbs_launcher = INSTALL_DIR / "launch_admin.vbs"
    _write_vbs_launcher(vbs_launcher, script_path)
    ok(f"VBS launcher: {vbs_launcher}")

    bat_launcher = INSTALL_DIR / "launch_admin_debug.bat"
    write_ansi(bat_launcher,
        f'@echo off\r\n'
        f'cd /d "{INSTALL_DIR}"\r\n'
        f'"{pythonw}" "{script_path}"\r\n'
        f'pause\r\n'
    )
    hide_file(bat_launcher)

    step("Creating desktop shortcut")
    try:
        desktop      = get_desktop()
        shortcut     = str(desktop / "TimeNet Admin.lnk")
        wscript      = r"C:\Windows\System32\wscript.exe"
        vbs_arg      = str(vbs_launcher)
        png_path     = INSTALL_DIR / "timenet.png"
        ico_path     = INSTALL_DIR / "timenet.ico"
        icon_path    = make_ico_from_png(png_path, ico_path) if png_path.exists() else None
        create_shortcut_vbs(
            target_exe    = wscript,
            target_args   = vbs_arg,
            shortcut_path = shortcut,
            icon_path     = icon_path,
        )
        ok(f"Shortcut: {shortcut}")
    except Exception as e:
        print(f"     ⚠  Could not create shortcut: {e}")

    remove_from_startup("TimeNet Admin Portal")

    _write_uninstaller("admin")

    banner("Admin Portal Installed Successfully!")
    print(f"""
  Installation directory : {INSTALL_DIR}
  Desktop shortcut       : TimeNet Admin.lnk
  Auto-starts with Windows: NO (launch manually)

  ┌──────────────────────────────────────────────────────┐
  │  IMPORTANT — Admin Exit Notes                       │
  │                                                      │
  │  • Admin portal is also fullscreen / locked.        │
  │  • To exit: press Ctrl+Shift+A → enter your PIN.   │
  │                                                      │
  │  • Closing any CMD / terminal will NOT kill the app.│
  └──────────────────────────────────────────────────────┘

  To uninstall: run  {INSTALL_DIR}\\uninstall.bat
""")


# ─────────────────────────────────────────────────────────────
#  UNINSTALLER
# ─────────────────────────────────────────────────────────────

def _write_uninstaller(role):
    step("Writing uninstaller")
    reg_names = {
        "customer": "TimeNet Customer Kiosk",
        "admin":    "TimeNet Admin Portal",
        "both":     "TimeNet Customer Kiosk",
    }
    reg_name = reg_names.get(role, "TimeNet Customer Kiosk")

    uninstall_py = INSTALL_DIR / "uninstall.py"
    uninstall_py.write_text(
        f"""import winreg, shutil, os, sys
from pathlib import Path

INSTALL_DIR = Path(r"{INSTALL_DIR}")
REG_KEY     = r"{STARTUP_REG_KEY}"
REG_NAME    = "{reg_name}"

print("TimeNet Cafe Uninstaller")
print("="*40)
try:
    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_KEY, 0, winreg.KEY_SET_VALUE)
    winreg.DeleteValue(key, REG_NAME)
    winreg.CloseKey(key)
    print("Removed startup entry.")
except Exception:
    pass

try:
    shutil.rmtree(str(INSTALL_DIR))
    print(f"Removed {{INSTALL_DIR}}")
except Exception as e:
    print(f"Could not remove {{INSTALL_DIR}}: {{e}}")

print("Uninstall complete. Remove desktop shortcut manually.")
input("Press Enter to close...")
""",
        encoding="utf-8"
    )

    uninstall_bat = INSTALL_DIR / "uninstall.bat"
    write_ansi(uninstall_bat,
        f'@echo off\r\n'
        f'"{find_python()}" "{uninstall_py}"\r\n'
        f'pause\r\n'
    )
    ok("uninstall.bat written")


# ─────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────

def main():
    if platform.system() != "Windows":
        fail("This installer only runs on Windows.")

    args = sys.argv[1:]
    if args:
        role = args[0].lower()
    else:
        print("""
╔══════════════════════════════════════╗
║      TimeNet Cafe  —  Installer     ║
╠══════════════════════════════════════╣
║  1. Customer Kiosk                  ║
║  2. Admin Portal                    ║
║  3. Both (on this machine)          ║
╚══════════════════════════════════════╝
""")
        choice = input("  Enter choice [1/2/3]: ").strip()
        role = {"1": "customer", "2": "admin", "3": "both"}.get(choice, "")
        if not role:
            fail("Invalid choice.")

    # Run configuration wizard
    cfg = run_config_wizard()

    if role == "customer":
        install_customer(cfg)
    elif role == "admin":
        install_admin(cfg)
    elif role == "both":
        install_customer(cfg)
        install_admin(cfg)
    else:
        fail(f"Unknown role: {role}. Use 'customer', 'admin', or 'both'.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n  Cancelled.")
    except SystemExit:
        raise
    except Exception:
        print("\n  Unexpected error:")
        traceback.print_exc()
        input("\n  Press Enter to close...")
