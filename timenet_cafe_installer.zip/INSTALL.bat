@echo off
title TimeNet Cafe - Installer
color 0B
cls

echo.
echo  ==========================================
echo        TimeNet Cafe  -  Installer
echo  ==========================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python is not installed or not in PATH.
    echo  Please install Python 3.10+ from https://python.org
    echo  Make sure to tick "Add Python to PATH" during install.
    pause
    exit /b 1
)

:: Run installer
python "%~dp0install.py" %*

pause
