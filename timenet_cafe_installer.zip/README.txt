╔══════════════════════════════════════════════════════════════╗
║            TimeNet Cafe  —  Deployment Package              ║
╚══════════════════════════════════════════════════════════════╝

WHAT'S INCLUDED
───────────────
  INSTALL.bat            ← Double-click to start the installer
  install.py             ← Installer logic (called by INSTALL.bat)
  customerNEW.py         ← Customer Kiosk app
  adminNEW.py            ← Admin Portal app
  gcash.png              ← GCash payment logo
  maya.png               ← Maya payment logo
  cash.png               ← Cash payment icon
  timenet.png            ← TimeNet logo
  timenet_newfinal.sql   ← Database schema + seed data
  README.txt             ← This file


REQUIREMENTS
────────────
  • Windows 10 or Windows 11
  • Python 3.10 or newer
      → Download: https://python.org
      → During install, TICK "Add Python to PATH"
  • XAMPP installed and running (Apache + MySQL)
  • Internet connection on first install (to download pip packages)


STEP 1 — SET UP THE DATABASE
──────────────────────────────
  1. Open XAMPP Control Panel
  2. Start Apache and MySQL
  3. Open your browser → go to: http://localhost/phpmyadmin
  4. Click "New" on the left sidebar
  5. Create a database named: timenet
  6. Click "Import" → choose: timenet_newfinal.sql
  7. Click "Go" to import


STEP 2 — RUN THE INSTALLER
────────────────────────────
  Double-click INSTALL.bat

  Choose what to install on this PC:

    1 → Customer Kiosk    (install on every customer computer)
    2 → Admin Portal      (install on the staff/cashier computer)
    3 → Both              (if one PC handles both roles)

  The installer will ask you for:
    • Your MySQL username and password
    • An exit PIN (used by staff to close the kiosk — see below)

  It will automatically:
    ✓ Install all required Python packages
    ✓ Copy app files to C:\TimeNet\
    ✓ Apply your database settings to the app files
    ✓ Create a desktop shortcut
    ✓ Register the Customer Kiosk to auto-start on Windows login


STEP 3 — SET UP EACH CUSTOMER PC
───────────────────────────────────
  Each customer PC must have its own unique computer ID.

  After installing the Customer Kiosk on a PC:
    1. Open: C:\TimeNet\customerNEW.py  (use Notepad or any text editor)
    2. Find this line near the top:
           THIS_COMPUTER_ID = "pc-01"
    3. Change it to a unique ID for each machine:
           pc-01, pc-02, pc-03, etc.
    4. Save the file.

  Make sure the matching computer record exists in your database
  (the SQL file includes starter entries for pc-01 through pc-05).


KIOSK LOCK & EXIT PIN
──────────────────────
  Both the Customer Kiosk and Admin Portal run in fullscreen
  lockdown mode:

    • No title bar or window controls
    • Windows key, Alt+F4, Ctrl+Esc, and Alt+Tab are all blocked
    • The taskbar is hidden while the kiosk is active

  To exit the app (staff only):
    Press  Ctrl + Shift + A  →  type your PIN  →  press Enter

  ⚠  IMPORTANT: Change the default PIN before deploying!

  The installer will ask you to set a PIN during setup.
  If you need to change it afterward:
    1. Open customerNEW.py and/or adminNEW.py in a text editor
    2. Find:   ADMIN_EXIT_PIN = "1234"
    3. Change "1234" to your own secret PIN
    4. Save the file


DATABASE CREDENTIALS
──────────────────────
  The installer patches these automatically, but here is where
  to find them if you need to change them manually later:

  customerNEW.py:
      DB_HOST     = "localhost"
      DB_USER     = "remoteuser"
      DB_PASSWORD = "123456"

  adminNEW.py:
      DB_HOST     = "localhost"
      DB_USER     = "root"
      DB_PASSWORD = ""

  Update these to match your XAMPP / MySQL configuration.


LAUNCHING THE APPS (AFTER INSTALL)
────────────────────────────────────
  Customer Kiosk:
    → Starts automatically when Windows boots (auto-start enabled)
    → Or double-click "TimeNet Kiosk" shortcut on the desktop

  Admin Portal:
    → Double-click "TimeNet Admin" shortcut on the desktop
    → Does NOT auto-start (launch manually when needed)


UNINSTALLING
─────────────
  1. Run:  C:\TimeNet\uninstall.bat
  2. Delete the desktop shortcuts manually
  3. The C:\TimeNet folder will be removed automatically


TROUBLESHOOTING
────────────────
  App won't start / Python error on launch:
    → Make sure Python 3.10+ is installed and in PATH
    → Run: python --version  in Command Prompt to check
    → Re-run INSTALL.bat to reinstall packages

  "Can't connect to database" error:
    → Open XAMPP and confirm MySQL is running (green)
    → Check that DB_HOST, DB_USER, DB_PASSWORD in the .py files
      match your MySQL setup

  Customer kiosk shows wrong computer:
    → Edit THIS_COMPUTER_ID in customerNEW.py (see Step 3 above)

  Forgot the exit PIN:
    → Open customerNEW.py or adminNEW.py in Notepad
    → Find ADMIN_EXIT_PIN and read or change the value
    → Save the file and restart the app


SUPPORT
────────
  For issues, contact your system administrator or the
  developer who provided this package.

