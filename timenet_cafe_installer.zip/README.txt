╔══════════════════════════════════════════════════════════╗
║          TimeNet Cafe  —  Deployment Package            ║
╚══════════════════════════════════════════════════════════╝

REQUIREMENTS
────────────
• Windows 10 / 11
• Python 3.10+  (https://python.org — tick "Add Python to PATH")
• XAMPP / MySQL running with the timenet database imported
• Internet access on first run (to install pip packages)


FIRST-TIME DATABASE SETUP
──────────────────────────
1. Open XAMPP → start Apache + MySQL
2. Go to phpMyAdmin → create database: timenet
3. Import:  timenet_newfinal.sql


HOW TO INSTALL
──────────────
Double-click  INSTALL.bat  and choose:

  1  →  Customer Kiosk   (run on each customer PC)
  2  →  Admin Portal     (run on the staff PC)
  3  →  Both             (if this PC runs both)

The installer will:
  ✓ Install all Python dependencies automatically
  ✓ Copy app files to  C:\TimeNet\
  ✓ Create a desktop shortcut
  ✓ Register the Customer Kiosk to auto-start with Windows


KIOSK LOCK FEATURES
────────────────────
Both apps run in fullscreen kiosk mode:
  • No title bar, no window controls
  • Windows key, Alt+F4, Ctrl+Esc, Alt+Tab all blocked
  • Task bar hidden while kiosk is locked
  • Exit only via:  Ctrl + Shift + A  →  enter PIN 1234

⚠  CHANGE THE EXIT PIN BEFORE DEPLOYING:
   Open customerNEW.py and adminNEW.py
   Find:  ADMIN_EXIT_PIN = "1234"
   Change to a secret PIN your staff know.


CUSTOMISE PC IDs
────────────────
Each customer PC must have its own computer ID.
Open customerNEW.py and find:

    THIS_COMPUTER_ID = "pc-01"

Change to "pc-02", "pc-03", etc. for each machine.
Make sure matching records exist in the computers table.


DATABASE CREDENTIALS
─────────────────────
customerNEW.py:
    DB_HOST     = "localhost"
    DB_USER     = "remoteuser"
    DB_PASSWORD = "123456"

adminNEW.py:
    DB_HOST     = "localhost"
    DB_USER     = "root"
    DB_PASSWORD = ""

Update these to match your XAMPP/MySQL setup.


UNINSTALL
──────────
Run  C:\TimeNet\uninstall.bat
Then delete the desktop shortcuts manually.


FILES IN THIS PACKAGE
──────────────────────
  INSTALL.bat          ← Double-click to install
  install.py           ← Installer logic (Python)
  customerNEW.py       ← Customer kiosk app
  adminNEW.py          ← Admin portal app
  gcash.png            ← GCash payment icon
  maya.png             ← Maya payment icon
  timenet.png          ← TimeNet logo
  timenet_newfinal.sql ← Database schema + seed data
  README.txt           ← This file
